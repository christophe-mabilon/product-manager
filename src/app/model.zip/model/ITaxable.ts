export interface ITaxable {
  calculatedCa(): number;
}
